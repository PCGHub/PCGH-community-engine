# PCGH — Reference MVP

A working, runnable implementation of the mechanics described in the PCGH Technical Build Plan: a credit ledger, a content submission flow, signup-time group auto-assignment, and — the core piece — a **distribution/matching engine** that assigns community engagement to submitted content while enforcing group diversity, rotation cooldowns, mixed engagement types, and staggered timing.

This is deliberately **zero-dependency**: no `npm install` required. It uses only Node's built-in `node:sqlite` and `node:http`, so it runs immediately on Node 22.5+. That makes it a fast way to see the logic work, and a reference implementation for your engineers to port into the production stack (Next.js + Postgres + Stripe) described in the build plan — not a replacement for that stack.

## Quick start

```bash
npm run seed   # creates demo groups + ~30 community members (via the real signup path) + a funded demo owner account
npm run dev    # starts the server on http://localhost:8787
npm test       # runs the distribution engine's unit tests
```

Then open `http://localhost:8787/login` and pick a member to browse as (no password — this is a demo, see "What this is not" below). Or open `http://localhost:8787/signup` to see the live group auto-assignment flow yourself.

## Walking through the core flow

1. **Sign up** at `/signup` — you're auto-placed into whichever community group still has room. Your dashboard only ever shows that one group, not the whole platform.
2. **Log in as the demo owner** (`demo@pcgh.local`, pre-loaded with 1,000 credits) via `/login`.
3. **Submit content** — pick a URL, platform, and engagement types. Costs 100 credits.
4. **Go to Admin → Run distribution now.** This simulates the background worker (Scheduler in the architecture diagram) picking up the pending submission and running the matching algorithm.
5. **Check the submission's stats page** — you'll see assignments spread across multiple groups and multiple engagement types.
6. **Log in as one of the assigned members** (`/login`) and check **My queue** — their assigned tasks appear there, staggered across scheduled times, and they can mark them complete.
7. **Check the Admin page** — it lists every group's fill level and lets you create a new group (name, category, capacity) on the spot. That's the entire mechanism for adding community capacity; nothing else changes.

## What's actually implemented

| Piece | File | Notes |
|---|---|---|
| Data model | `src/db.ts` | SQLite schema matching Section 2 of the build plan (users, credit_wallets, credit_transactions, groups w/ capacity, group_memberships, submissions, assignments, rotation_log). |
| Group auto-assignment | `db.ts: signUpMember / assignMemberToNextAvailableGroup / listGroupsWithCounts` | Fills groups in creation order; once a group hits capacity, new signups move to the next one. Admin creates groups from the UI — no code changes. |
| Distribution engine | `src/distribution.ts` | Pure, dependency-free functions: `selectEligible` (rotation cooldown), `spreadAcrossGroups` (group diversity + per-group cap), `allocateTypes` (mixed engagement types), `jitteredOffsetMs` (staggered scheduling). |
| Worker | `db.ts: runDistributionWorker()` | Simulates the async job described in the architecture — triggered from `/admin` here; on a cron/queue in production. |
| Credit ledger | `db.ts: purchaseCredits / submitContent` | Immutable transaction log, not just a balance field. |
| UI | `src/server.ts` | Plain server-rendered HTML, no framework. Includes `/signup`, single-group dashboard, and admin group management. |
| Tests | `src/distribution.test.ts` | Proves the three algorithmic guarantees hold (see below). |

## What the tests prove

Run `npm test`. It asserts, with synthetic data, that the distribution engine actually enforces the five principles from the business model doc rather than just claiming to:

- **Group diversity** — assignments span at least `MIN_GROUPS` distinct groups, and no single group supplies more than `maxSharePerGroup` of the total.
- **Rotation exclusion** — a member assigned to a creator is excluded from re-selection for that same creator until the cooldown window (`COOLDOWN_DAYS`) expires, then becomes eligible again.
- **Time spread** — scheduled times are jittered across a window, not clustered at a single instant.
- **Mixed types** — multiple requested engagement types actually get used, not just one.

(The group-diversity guarantee doesn't depend on whether a member belongs to one group or several — it depends on the algorithm drawing from many groups' member pools, which holds either way.)

## What this is *not*

This is a reference implementation of the logic, not a production system. Specifically it does **not** include:

- Real authentication (it uses a `?as=<userId>` query param — anyone can act as anyone). Replace with NextAuth/Clerk before this touches real users.
- Real payments (credit purchases are instant and free). Wire up Stripe before taking money.
- The trust & safety / verification layer described in Section 4 of the build plan (dwell-time checks, platform-side confirmation, anomaly detection). "Mark complete" here is a self-reported click.
- Postgres, Redis, or a real job queue — SQLite and an admin button stand in for those so this runs with zero setup.
- Rate limiting, input sanitization, or any other production hardening.

Port the schema and the `src/distribution.ts` / `src/db.ts` group-assignment logic into the Phase 1 stack (Section 5 of the Technical Build Plan) as your next step; the algorithm and data model don't need to change, only where they run.

## Tuning the algorithm

The constants that matter are in `src/types.ts` (`DEFAULT_CONFIG`, `TYPE_RATIOS`) and `db.ts` (`CREDITS_PER_LINK`, `ASSIGNMENTS_PER_SUBMISSION`, group `capacity` passed to `createGroup`). See Section 3 of the build plan for what each one controls and why it shouldn't be hard-coded in production. Demo groups are seeded with capacity 8 (not the production default of 100) specifically so the "group fills up, next signup moves to the next group" behavior is visible with just ~30 seeded members — see `src/seed.ts`.
