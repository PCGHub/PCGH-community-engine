// Seeds demo data using the *real* signup path (signUpMember), so the seed
// data behaves exactly like production signups: each member is auto-
// assigned into whichever group still has room, in creation order.
//
// Demo groups are seeded with a small capacity (8) instead of the
// production default (100) so that with ~30 seeded members you can
// actually see the "fills up, moves to the next group" behavior without
// needing thousands of fake signups. Create real groups from the Admin
// page with capacity 100 (or whatever you want) - nothing here is
// hard-coded to 8.

import { createGroup, signUpMember, purchaseCredits, listGroupsWithCounts } from "./db.js";

const GROUPS = [
  { name: "Fitness & Wellness", category: "fitness" },
  { name: "Tech & SaaS", category: "tech" },
  { name: "Fashion & Beauty", category: "fashion" },
  { name: "Food & Cooking", category: "food" },
  { name: "Music & Art", category: "music" },
];
const DEMO_GROUP_CAPACITY = 8;

console.log("Seeding PCGH demo data...\n");

for (const g of GROUPS) createGroup(g.name, g.category, DEMO_GROUP_CAPACITY);
console.log(`Created ${GROUPS.length} groups (capacity ${DEMO_GROUP_CAPACITY} each, for demo purposes).`);

const { userId: demoOwnerId, group: demoOwnerGroup } = signUpMember("Demo Creator (you)", "demo@pcgh.local", "growth", 5);
purchaseCredits(demoOwnerId, 1000);
console.log(`Created demo owner account: demo@pcgh.local (1,000 credits) -> assigned to "${demoOwnerGroup?.name}"`);

const FIRST_NAMES = [
  "Ava", "Liam", "Maya", "Noah", "Zoe", "Ethan", "Ivy", "Leo",
  "Mia", "Kai", "Ruby", "Finn", "Nora", "Owen", "Luna", "Theo",
  "Ella", "Max", "Sofia", "Jude", "Aria", "Cole", "Wren", "Rhys",
  "Skye", "Beau", "Nova", "Reid", "Tess", "Jax",
];

let userCount = 0;
for (let i = 0; i < FIRST_NAMES.length; i++) {
  const name = FIRST_NAMES[i];
  const email = `${name.toLowerCase()}${i}@pcgh.local`;
  signUpMember(name, email, "starter", 5);
  userCount++;
}

console.log(`Signed up ${userCount} community members via the real signup path (auto-assigned by capacity).\n`);

console.log("Group fill after seeding:");
for (const g of listGroupsWithCounts()) {
  console.log(`  ${g.name}: ${g.member_count}/${g.capacity}`);
}

console.log("\nSeed complete. Run `npm run dev` and open http://localhost:8787");
console.log("Log in as the demo owner via: http://localhost:8787/login");
console.log("Or try the live signup flow yourself at: http://localhost:8787/signup");
