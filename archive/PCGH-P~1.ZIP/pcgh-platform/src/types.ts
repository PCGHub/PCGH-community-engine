// Shared types for the PCGH reference MVP.
// This mirrors the data model in Section 2 of the Technical Build Plan.

export type EngagementType =
  | "view"
  | "watch_time"
  | "like"
  | "comment"
  | "share"
  | "save"
  | "click"
  | "profile_visit";

export const ALL_ENGAGEMENT_TYPES: EngagementType[] = [
  "view",
  "watch_time",
  "like",
  "comment",
  "share",
  "save",
  "click",
  "profile_visit",
];

// Realistic engagement ratios - views dominate, comments are rare.
// Tune per-platform in production; see Section 3 of the build plan.
export const TYPE_RATIOS: Record<EngagementType, number> = {
  view: 0.38,
  watch_time: 0.14,
  like: 0.2,
  comment: 0.07,
  share: 0.05,
  save: 0.06,
  click: 0.06,
  profile_visit: 0.04,
};

export interface Member {
  id: string;
  name: string;
  groupIds: string[];
  dailyQuotaRemaining: number;
  status: "active" | "suspended";
}

export interface RotationEntry {
  ownerId: string;
  memberId: string;
  lastAssignedAt: number; // epoch ms
}

export interface DistributionAssignment {
  memberId: string;
  groupId: string;
  engagementType: EngagementType;
  scheduledAt: number; // epoch ms
}

export interface DistributionInput {
  submissionId: string;
  ownerId: string;
  requestedTypes: EngagementType[];
  targetCount: number;
  members: Member[];
  rotationLog: RotationEntry[];
  now: number;
}

export interface DistributionConfig {
  cooldownDays: number;
  minGroups: number;
  maxSharePerGroup: number; // e.g. 0.4 = no single group supplies >40% of assignees
  windowMinMinutes: number;
  windowMaxMinutes: number;
}

export const DEFAULT_CONFIG: DistributionConfig = {
  cooldownDays: 14,
  minGroups: 3,
  maxSharePerGroup: 0.4,
  windowMinMinutes: 15,
  windowMaxMinutes: 60 * 48, // up to 48 hours out
};
