// Data layer. Uses Node's built-in node:sqlite (no external dependency) so
// this MVP runs with zero `npm install`. Swap for Postgres + Prisma using
// the same schema for production (see Section 5 of the Technical Build Plan).

import { DatabaseSync } from "node:sqlite";
import { randomUUID } from "node:crypto";
import { mkdirSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { distribute, makeRng } from "./distribution.js";
import { DEFAULT_CONFIG } from "./types.js";
import type { Member, RotationEntry, DistributionInput, EngagementType } from "./types.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, "..", "data");
if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = join(DATA_DIR, "pcgh.db");

export const db = new DatabaseSync(DB_PATH);

db.exec(`
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    tier TEXT NOT NULL DEFAULT 'starter',
    status TEXT NOT NULL DEFAULT 'active',
    daily_quota INTEGER NOT NULL DEFAULT 5,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS credit_wallets (
    user_id TEXT PRIMARY KEY REFERENCES users(id),
    balance INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS credit_transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    type TEXT NOT NULL, -- 'purchase' | 'spend'
    amount INTEGER NOT NULL,
    ref_id TEXT,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS groups (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    capacity INTEGER NOT NULL DEFAULT 100,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS group_memberships (
    user_id TEXT NOT NULL REFERENCES users(id),
    group_id TEXT NOT NULL REFERENCES groups(id),
    PRIMARY KEY (user_id, group_id)
  );

  CREATE TABLE IF NOT EXISTS submissions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    url TEXT NOT NULL,
    platform TEXT NOT NULL,
    requested_types TEXT NOT NULL, -- comma-separated EngagementType[]
    credits_cost INTEGER NOT NULL,
    target_count INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending_distribution', -- pending_distribution | distributed
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS assignments (
    id TEXT PRIMARY KEY,
    submission_id TEXT NOT NULL REFERENCES submissions(id),
    member_user_id TEXT NOT NULL REFERENCES users(id),
    engagement_type TEXT NOT NULL,
    group_id TEXT NOT NULL,
    scheduled_at INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', -- pending | completed | expired
    completed_at INTEGER
  );

  CREATE TABLE IF NOT EXISTS rotation_log (
    owner_user_id TEXT NOT NULL,
    member_user_id TEXT NOT NULL,
    last_assigned_at INTEGER NOT NULL,
    PRIMARY KEY (owner_user_id, member_user_id)
  );
`);

// ---------- Users / groups ----------

export function createUser(name: string, email: string, tier = "starter", dailyQuota = 5) {
  const id = randomUUID();
  db.prepare(
    "INSERT INTO users (id, name, email, tier, status, daily_quota, created_at) VALUES (?, ?, ?, 'active', 'active', ?, ?)"
  ).run(id, name, email, dailyQuota, Date.now());
  db.prepare("INSERT INTO credit_wallets (user_id, balance) VALUES (?, 0)").run(id);
  return id;
}

export function createGroup(name: string, category: string, capacity = 100) {
  const id = randomUUID();
  db.prepare("INSERT INTO groups (id, name, category, capacity, created_at) VALUES (?, ?, ?, ?, ?)").run(
    id,
    name,
    category,
    capacity,
    Date.now()
  );
  return id;
}

export function addUserToGroup(userId: string, groupId: string) {
  db.prepare("INSERT OR IGNORE INTO group_memberships (user_id, group_id) VALUES (?, ?)").run(userId, groupId);
}

/** Groups with a live member_count alongside their capacity, oldest first. */
export function listGroupsWithCounts(): any[] {
  return db
    .prepare(
      `SELECT g.*, COUNT(gm.user_id) as member_count
       FROM groups g
       LEFT JOIN group_memberships gm ON gm.group_id = g.id
       GROUP BY g.id
       ORDER BY g.created_at ASC`
    )
    .all();
}

/**
 * Signup-time group assignment: fills groups in creation order, moving to
 * the next group once the current one hits capacity. This is what makes
 * "member 1 sees group 1, member 101 sees group 2" happen automatically -
 * no code change needed to add capacity, just create another group from
 * the admin page.
 */
export function assignMemberToNextAvailableGroup(userId: string): any | null {
  const groups = listGroupsWithCounts();
  const open = groups.find((g) => g.member_count < g.capacity);
  if (!open) return null;
  addUserToGroup(userId, open.id);
  return open;
}

/** The single group a member currently belongs to (their assigned community), if any. */
export function getMemberGroup(userId: string): any {
  return db
    .prepare(
      `SELECT g.* FROM groups g
       JOIN group_memberships gm ON gm.group_id = g.id
       WHERE gm.user_id = ?
       LIMIT 1`
    )
    .get(userId);
}

/**
 * The real signup path: create the account, then auto-assign into whichever
 * group still has room (round-robin fill by capacity). If every existing
 * group is full, the account is still created but left unassigned - the
 * dashboard will say so, and an admin opening one more group (Section 9 of
 * the build plan / the Admin page here) is all it takes to unblock them.
 */
export function signUpMember(name: string, email: string, tier = "starter", dailyQuota = 5) {
  const userId = createUser(name, email, tier, dailyQuota);
  const group = assignMemberToNextAvailableGroup(userId);
  return { userId, group };
}

export function listUsers(): any[] {
  return db.prepare("SELECT * FROM users ORDER BY created_at ASC").all();
}

export function getUser(userId: string): any {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
}

// ---------- Credits ----------

export function getBalance(userId: string): number {
  const row = db.prepare("SELECT balance FROM credit_wallets WHERE user_id = ?").get(userId) as any;
  return row ? Number(row.balance) : 0;
}

export function purchaseCredits(userId: string, amount: number) {
  db.prepare("UPDATE credit_wallets SET balance = balance + ? WHERE user_id = ?").run(amount, userId);
  db.prepare(
    "INSERT INTO credit_transactions (id, user_id, type, amount, ref_id, created_at) VALUES (?, ?, 'purchase', ?, NULL, ?)"
  ).run(randomUUID(), userId, amount, Date.now());
}

function spendCredits(userId: string, amount: number, refId: string) {
  const balance = getBalance(userId);
  if (balance < amount) throw new Error("Insufficient credits");
  db.prepare("UPDATE credit_wallets SET balance = balance - ? WHERE user_id = ?").run(amount, userId);
  db.prepare(
    "INSERT INTO credit_transactions (id, user_id, type, amount, ref_id, created_at) VALUES (?, ?, 'spend', ?, ?, ?)"
  ).run(randomUUID(), userId, amount, refId, Date.now());
}

// ---------- Submissions ----------

const CREDITS_PER_LINK = 100;
const ASSIGNMENTS_PER_SUBMISSION = 20;

export function submitContent(
  userId: string,
  url: string,
  platform: string,
  requestedTypes: EngagementType[]
) {
  const id = randomUUID();
  spendCredits(userId, CREDITS_PER_LINK, id);
  db.prepare(
    `INSERT INTO submissions (id, user_id, url, platform, requested_types, credits_cost, target_count, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'pending_distribution', ?)`
  ).run(id, userId, url, platform, requestedTypes.join(","), CREDITS_PER_LINK, ASSIGNMENTS_PER_SUBMISSION, Date.now());
  return id;
}

export function listSubmissionsForUser(userId: string): any[] {
  return db.prepare("SELECT * FROM submissions WHERE user_id = ? ORDER BY created_at DESC").all(userId);
}

export function getSubmission(id: string): any {
  return db.prepare("SELECT * FROM submissions WHERE id = ?").get(id);
}

export function listPendingSubmissions(): any[] {
  return db.prepare("SELECT * FROM submissions WHERE status = 'pending_distribution'").all();
}

// ---------- Distribution worker ----------

function toMember(row: any, groupIdsByUser: Map<string, string[]>): Member {
  return {
    id: row.id,
    name: row.name,
    groupIds: groupIdsByUser.get(row.id) ?? [],
    dailyQuotaRemaining: row.daily_quota,
    status: row.status,
  };
}

/**
 * Simulates the Scheduler/Worker from the architecture diagram: processes
 * every submission still pending distribution, runs the matching algorithm,
 * persists assignments, and updates the rotation log. In production this
 * runs on a cron/job queue (Section 1); here it's invoked from an admin
 * route or the CLI to keep the MVP dependency-free.
 */
export function runDistributionWorker(now: number = Date.now()): { submissionId: string; assigned: number }[] {
  const results: { submissionId: string; assigned: number }[] = [];
  const users = listUsers().filter((u) => u.status === "active");
  const memberships = db.prepare("SELECT user_id, group_id FROM group_memberships").all() as any[];
  const groupIdsByUser = new Map<string, string[]>();
  for (const m of memberships) {
    const list = groupIdsByUser.get(m.user_id) ?? [];
    list.push(m.group_id);
    groupIdsByUser.set(m.user_id, list);
  }
  const members: Member[] = users.map((u) => toMember(u, groupIdsByUser));

  const rotationRows = db.prepare("SELECT owner_user_id, member_user_id, last_assigned_at FROM rotation_log").all() as any[];
  const rotationLog: RotationEntry[] = rotationRows.map((r) => ({
    ownerId: r.owner_user_id,
    memberId: r.member_user_id,
    lastAssignedAt: r.last_assigned_at,
  }));

  const pending = listPendingSubmissions();
  for (const sub of pending) {
    const requestedTypes = sub.requested_types.split(",").filter(Boolean) as EngagementType[];
    const input: DistributionInput = {
      submissionId: sub.id,
      ownerId: sub.user_id,
      requestedTypes,
      targetCount: sub.target_count,
      members,
      rotationLog,
      now,
    };
    // Seed the RNG from the submission id so results are reproducible per
    // submission but still vary across submissions/runs.
    const seed = Array.from(sub.id as string).reduce((acc: number, ch: string) => acc + ch.charCodeAt(0), 0) + now;
    const assignments = distribute(input, DEFAULT_CONFIG, makeRng(seed));

    for (const a of assignments) {
      db.prepare(
        `INSERT INTO assignments (id, submission_id, member_user_id, engagement_type, group_id, scheduled_at, status)
         VALUES (?, ?, ?, ?, ?, ?, 'pending')`
      ).run(randomUUID(), sub.id, a.memberId, a.engagementType, a.groupId, a.scheduledAt);

      db.prepare(
        `INSERT INTO rotation_log (owner_user_id, member_user_id, last_assigned_at)
         VALUES (?, ?, ?)
         ON CONFLICT(owner_user_id, member_user_id) DO UPDATE SET last_assigned_at = excluded.last_assigned_at`
      ).run(sub.user_id, a.memberId, now);

      // keep the in-memory rotationLog current across submissions processed
      // in this same worker pass
      rotationLog.push({ ownerId: sub.user_id, memberId: a.memberId, lastAssignedAt: now });
    }

    db.prepare("UPDATE submissions SET status = 'distributed' WHERE id = ?").run(sub.id);
    results.push({ submissionId: sub.id, assigned: assignments.length });
  }

  return results;
}

// ---------- Engagement queue ----------

export function getQueueForMember(userId: string, now: number = Date.now()): any[] {
  return db
    .prepare(
      `SELECT a.*, s.url, s.platform, s.user_id as owner_id
       FROM assignments a
       JOIN submissions s ON s.id = a.submission_id
       WHERE a.member_user_id = ? AND a.status = 'pending' AND a.scheduled_at <= ?
       ORDER BY a.scheduled_at ASC`
    )
    .all(userId, now);
}

export function getUpcomingForMember(userId: string, now: number = Date.now()): any[] {
  return db
    .prepare(
      `SELECT a.*, s.url, s.platform
       FROM assignments a
       JOIN submissions s ON s.id = a.submission_id
       WHERE a.member_user_id = ? AND a.status = 'pending' AND a.scheduled_at > ?
       ORDER BY a.scheduled_at ASC`
    )
    .all(userId, now);
}

export function completeAssignment(assignmentId: string, now: number = Date.now()) {
  db.prepare("UPDATE assignments SET status = 'completed', completed_at = ? WHERE id = ?").run(now, assignmentId);
}

export function getAssignment(assignmentId: string): any {
  return db.prepare("SELECT * FROM assignments WHERE id = ?").get(assignmentId);
}

export function getSubmissionStats(submissionId: string): any {
  const rows = db
    .prepare(
      `SELECT engagement_type, status, COUNT(*) as n, GROUP_CONCAT(DISTINCT group_id) as groups
       FROM assignments WHERE submission_id = ? GROUP BY engagement_type, status`
    )
    .all(submissionId) as any[];
  const totalAssigned = db.prepare("SELECT COUNT(*) as n FROM assignments WHERE submission_id = ?").get(submissionId) as any;
  const totalCompleted = db
    .prepare("SELECT COUNT(*) as n FROM assignments WHERE submission_id = ? AND status = 'completed'")
    .get(submissionId) as any;
  const distinctGroups = db
    .prepare("SELECT COUNT(DISTINCT group_id) as n FROM assignments WHERE submission_id = ?")
    .get(submissionId) as any;
  return {
    breakdown: rows,
    totalAssigned: totalAssigned?.n ?? 0,
    totalCompleted: totalCompleted?.n ?? 0,
    distinctGroups: distinctGroups?.n ?? 0,
  };
}

export function listGroups(): any[] {
  return db.prepare("SELECT * FROM groups").all();
}
