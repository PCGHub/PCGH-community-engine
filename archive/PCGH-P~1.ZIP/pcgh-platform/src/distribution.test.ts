// Plain assert-based tests (no test framework dependency) proving the three
// guarantees the distribution engine is supposed to enforce:
//   1. Rotation exclusion - no repeat pairing inside the cooldown window
//   2. Group diversity   - assignments span multiple groups, not one
//   3. Time spread        - scheduled_at values are not clustered/identical
//
// Run with: tsx src/distribution.test.ts

import assert from "node:assert/strict";
import {
  distribute,
  selectEligible,
  distinctGroupCount,
  makeRng,
} from "./distribution.js";
import type { Member, RotationEntry, DistributionInput } from "./types.js";
import { DEFAULT_CONFIG } from "./types.js";

function buildMembers(): Member[] {
  const groups = ["g1", "g2", "g3", "g4"];
  const members: Member[] = [];
  for (let i = 0; i < 40; i++) {
    members.push({
      id: `m${i}`,
      name: `Member ${i}`,
      groupIds: [groups[i % groups.length], groups[(i + 1) % groups.length]],
      dailyQuotaRemaining: 5,
      status: "active",
    });
  }
  return members;
}

let passed = 0;
function test(name: string, fn: () => void) {
  try {
    fn();
    passed++;
    console.log(`  ok - ${name}`);
  } catch (err) {
    console.error(`  FAIL - ${name}`);
    console.error(err);
    process.exitCode = 1;
  }
}

console.log("distribution engine tests");

test("group diversity: assignments span at least MIN_GROUPS groups", () => {
  const members = buildMembers();
  const now = Date.now();
  const input: DistributionInput = {
    submissionId: "s1",
    ownerId: "owner1",
    requestedTypes: ["view", "like", "comment"],
    targetCount: 20,
    members,
    rotationLog: [],
    now,
  };
  const rng = makeRng(42);
  const assignments = distribute(input, DEFAULT_CONFIG, rng);

  assert.ok(assignments.length > 0, "expected some assignments");
  const groups = distinctGroupCount(assignments);
  assert.ok(
    groups >= DEFAULT_CONFIG.minGroups,
    `expected >= ${DEFAULT_CONFIG.minGroups} distinct groups, got ${groups}`
  );
});

test("no single group supplies more than maxSharePerGroup of assignees", () => {
  const members = buildMembers();
  const now = Date.now();
  const input: DistributionInput = {
    submissionId: "s2",
    ownerId: "owner1",
    requestedTypes: ["view", "like"],
    targetCount: 20,
    members,
    rotationLog: [],
    now,
  };
  const rng = makeRng(7);
  const assignments = distribute(input, DEFAULT_CONFIG, rng);

  const counts: Record<string, number> = {};
  for (const a of assignments) counts[a.groupId] = (counts[a.groupId] ?? 0) + 1;
  const cap = Math.ceil(assignments.length * DEFAULT_CONFIG.maxSharePerGroup);
  for (const [g, c] of Object.entries(counts)) {
    assert.ok(c <= cap, `group ${g} supplied ${c}, cap is ${cap}`);
  }
});

test("rotation exclusion: a member assigned to an owner is excluded from re-selection within the cooldown window", () => {
  const members = buildMembers();
  const now = Date.now();

  const firstRun = distribute(
    {
      submissionId: "s3a",
      ownerId: "owner2",
      requestedTypes: ["view", "like", "comment"],
      targetCount: 15,
      members,
      rotationLog: [],
      now,
    },
    DEFAULT_CONFIG,
    makeRng(1)
  );

  const rotationLog: RotationEntry[] = firstRun.map((a) => ({
    ownerId: "owner2",
    memberId: a.memberId,
    lastAssignedAt: now,
  }));

  // Second submission from the same owner, one day later (well inside the
  // 14-day cooldown) - none of the previously-assigned members should
  // reappear as eligible.
  const oneDayLater = now + 24 * 60 * 60 * 1000;
  const eligibleSecondRun = selectEligible(
    members,
    "owner2",
    rotationLog,
    oneDayLater,
    DEFAULT_CONFIG.cooldownDays
  );

  const firstRunIds = new Set(firstRun.map((a) => a.memberId));
  for (const m of eligibleSecondRun) {
    assert.ok(!firstRunIds.has(m.id), `member ${m.id} should be on cooldown but was eligible again`);
  }

  // After the cooldown window fully elapses, members should become
  // eligible again.
  const afterCooldown = now + (DEFAULT_CONFIG.cooldownDays + 1) * 24 * 60 * 60 * 1000;
  const eligibleAfterCooldown = selectEligible(
    members,
    "owner2",
    rotationLog,
    afterCooldown,
    DEFAULT_CONFIG.cooldownDays
  );
  const reeligible = eligibleAfterCooldown.filter((m) => firstRunIds.has(m.id));
  assert.ok(reeligible.length > 0, "expected previously-assigned members to be eligible again after cooldown expires");
});

test("time spread: scheduled_at values are not clustered at a single instant", () => {
  const members = buildMembers();
  const now = Date.now();
  const input: DistributionInput = {
    submissionId: "s4",
    ownerId: "owner3",
    requestedTypes: ["view", "like", "share", "save"],
    targetCount: 20,
    members,
    rotationLog: [],
    now,
  };
  const assignments = distribute(input, DEFAULT_CONFIG, makeRng(99));

  const times = assignments.map((a) => a.scheduledAt);
  const uniqueTimes = new Set(times);
  assert.ok(
    uniqueTimes.size >= Math.floor(times.length * 0.8),
    `expected mostly-distinct schedule times, got ${uniqueTimes.size}/${times.length} unique`
  );

  const span = Math.max(...times) - Math.min(...times);
  const minExpectedSpanMs = 30 * 60 * 1000; // at least 30 minutes of spread
  assert.ok(span > minExpectedSpanMs, `expected schedule spread > 30min, got ${span / 60000}min`);
});

test("mixed engagement types: multiple requested types actually get used", () => {
  const members = buildMembers();
  const now = Date.now();
  const input: DistributionInput = {
    submissionId: "s5",
    ownerId: "owner4",
    requestedTypes: ["view", "like", "comment", "share"],
    targetCount: 25,
    members,
    rotationLog: [],
    now,
  };
  const assignments = distribute(input, DEFAULT_CONFIG, makeRng(5));
  const typesUsed = new Set(assignments.map((a) => a.engagementType));
  assert.ok(typesUsed.size > 1, `expected multiple engagement types, got only ${[...typesUsed]}`);
});

console.log(`\n${passed} test(s) passed`);
if (process.exitCode) {
  console.error("\nSome tests FAILED");
} else {
  console.log("All tests passed.");
}
