// The distribution / matching engine - the core IP described in Section 3
// of the Technical Build Plan. Pure functions over plain data so this can
// be unit tested without touching the database (see distribution.test.ts).
//
// Guarantees this module is responsible for enforcing:
//   1. Different user groups   -> spreadAcrossGroups()
//   2. Time delays             -> jitteredOffsetMs() applied per assignment
//   3. Rotational exposure     -> cooldown filtering via rotationLog
//   4. Mixed engagement types  -> allocateTypes()
//   5. Human participation     -> enforced upstream (members are real
//                                 accounts; see Trust & Safety, Section 4)

import type {
  Member,
  RotationEntry,
  DistributionAssignment,
  DistributionInput,
  DistributionConfig,
  EngagementType,
} from "./types.js";
import { TYPE_RATIOS, DEFAULT_CONFIG } from "./types.js";

function daysToMs(days: number): number {
  return days * 24 * 60 * 60 * 1000;
}

/** Simple seedable PRNG (mulberry32) so tests can be deterministic. */
export function makeRng(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(arr: T[], rng: () => number): T[] {
  const out = arr.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/**
 * Step 1: filter members eligible for this submission.
 * Excludes the owner, inactive members, members with no quota left,
 * and members still inside the rotation cooldown window with this owner.
 */
export function selectEligible(
  members: Member[],
  ownerId: string,
  rotationLog: RotationEntry[],
  now: number,
  cooldownDays: number
): Member[] {
  const cooldownMs = daysToMs(cooldownDays);
  const recentlyAssigned = new Set(
    rotationLog
      .filter((r) => r.ownerId === ownerId && now - r.lastAssignedAt < cooldownMs)
      .map((r) => r.memberId)
  );

  return members.filter(
    (m) =>
      m.id !== ownerId &&
      m.status === "active" &&
      m.dailyQuotaRemaining > 0 &&
      !recentlyAssigned.has(m.id)
  );
}

/**
 * Step 2: pick `targetCount` members, spread across at least `minGroups`
 * distinct groups (when that many are available), and never let one group
 * supply more than `maxSharePerGroup` of the total.
 */
export interface GroupedPick {
  member: Member;
  drawnFromGroupId: string; // the group bucket this member was actually drawn from
}

export function spreadAcrossGroups(
  eligible: Member[],
  targetCount: number,
  minGroups: number,
  maxSharePerGroup: number,
  rng: () => number
): GroupedPick[] {
  const groupIds = Array.from(new Set(eligible.flatMap((m) => m.groupIds)));
  const shuffledGroups = shuffle(groupIds, rng);

  const bucket: Record<string, Member[]> = {};
  for (const g of shuffledGroups) {
    bucket[g] = shuffle(
      eligible.filter((m) => m.groupIds.includes(g)),
      rng
    );
  }

  const perGroupCap = Math.max(1, Math.ceil(targetCount * maxSharePerGroup));
  const selected: GroupedPick[] = [];
  const selectedIds = new Set<string>();
  const takenPerGroup: Record<string, number> = {};

  let progress = true;
  while (selected.length < targetCount && progress) {
    progress = false;
    for (const g of shuffledGroups) {
      if (selected.length >= targetCount) break;
      const list = bucket[g];
      if (!list || list.length === 0) continue;
      if ((takenPerGroup[g] ?? 0) >= perGroupCap) continue;

      // pop next unused member from this group's bucket
      while (list.length > 0) {
        const candidate = list.shift()!;
        if (selectedIds.has(candidate.id)) continue;
        // The group this member is *reported* under is the one they were
        // actually drawn from here - not an arbitrary groupIds[0] - so the
        // per-group cap enforced above matches what gets persisted.
        selected.push({ member: candidate, drawnFromGroupId: g });
        selectedIds.add(candidate.id);
        takenPerGroup[g] = (takenPerGroup[g] ?? 0) + 1;
        progress = true;
        break;
      }
    }
  }

  // Soft guarantee: if fewer distinct groups exist than minGroups, that's a
  // capacity problem (not enough community breadth yet), not a bug -
  // surface it to the caller via the returned group count rather than throw.
  return selected;
}

/**
 * Step 3: allocate an engagement type to each selected member, proportional
 * to TYPE_RATIOS restricted to the types this submission actually requested.
 */
export function allocateTypes(
  members: Member[],
  requestedTypes: EngagementType[],
  rng: () => number
): Map<string, EngagementType> {
  const types = requestedTypes.length > 0 ? requestedTypes : (Object.keys(TYPE_RATIOS) as EngagementType[]);
  const weights = types.map((t) => TYPE_RATIOS[t] ?? 0.05);
  const totalWeight = weights.reduce((a, b) => a + b, 0);

  const result = new Map<string, EngagementType>();
  const shuffled = shuffle(members, rng);

  for (const m of shuffled) {
    let r = rng() * totalWeight;
    let chosen: EngagementType = types[types.length - 1];
    for (let i = 0; i < types.length; i++) {
      r -= weights[i];
      if (r <= 0) {
        chosen = types[i];
        break;
      }
    }
    result.set(m.id, chosen);
  }
  return result;
}

/** Step 4: jittered scheduling offset so assignments don't land in a burst. */
export function jitteredOffsetMs(
  minMinutes: number,
  maxMinutes: number,
  rng: () => number
): number {
  const minutes = minMinutes + rng() * (maxMinutes - minMinutes);
  return Math.round(minutes * 60 * 1000);
}

/**
 * Full pipeline: eligible -> group-spread -> type-allocated -> time-jittered.
 * Returns the assignments to persist, plus the members who should be
 * excluded from this owner going forward (for updating the rotation log).
 */
export function distribute(
  input: DistributionInput,
  config: DistributionConfig = DEFAULT_CONFIG,
  rng: () => number = Math.random
): DistributionAssignment[] {
  const eligible = selectEligible(
    input.members,
    input.ownerId,
    input.rotationLog,
    input.now,
    config.cooldownDays
  );

  const picks = spreadAcrossGroups(
    eligible,
    input.targetCount,
    config.minGroups,
    config.maxSharePerGroup,
    rng
  );

  const typeByMember = allocateTypes(
    picks.map((p) => p.member),
    input.requestedTypes,
    rng
  );

  return picks.map(({ member, drawnFromGroupId }) => ({
    memberId: member.id,
    groupId: drawnFromGroupId,
    engagementType: typeByMember.get(member.id) ?? "view",
    scheduledAt: input.now + jitteredOffsetMs(config.windowMinMinutes, config.windowMaxMinutes, rng),
  }));
}

/** Count of distinct groups represented in a set of assignments. */
export function distinctGroupCount(assignments: DistributionAssignment[]): number {
  return new Set(assignments.map((a) => a.groupId)).size;
}
