// Minimal server-rendered UI + JSON-free HTML forms. No framework
// dependency (see README for why) - this is a reference implementation of
// the flows in the Technical Build Plan, not a production app.
//
// Demo auth: pass ?as=<userId> on any link. There is no password/session -
// this is intentionally not production auth (see README "What this is not").

import { createServer } from "node:http";
import type { IncomingMessage, ServerResponse } from "node:http";
import { URL } from "node:url";
import {
  listUsers,
  getUser,
  getBalance,
  purchaseCredits,
  submitContent,
  listSubmissionsForUser,
  getSubmission,
  runDistributionWorker,
  getQueueForMember,
  getUpcomingForMember,
  completeAssignment,
  getAssignment,
  getSubmissionStats,
  listGroupsWithCounts,
  getMemberGroup,
  signUpMember,
  createGroup,
} from "./db.js";
import { ALL_ENGAGEMENT_TYPES } from "./types.js";
import type { EngagementType } from "./types.js";

const PORT = process.env.PORT ? Number(process.env.PORT) : 8787;

function layout(title: string, body: string, asUserId?: string): string {
  const nav = asUserId
    ? `<a href="/?as=${asUserId}">Dashboard</a> ·
       <a href="/submit?as=${asUserId}">Submit content</a> ·
       <a href="/queue?as=${asUserId}">My queue</a> ·
       <a href="/credits/buy?as=${asUserId}">Buy credits</a> ·
       <a href="/admin?as=${asUserId}">Admin: run distribution</a> ·
       <a href="/login">Switch user</a>`
    : `<a href="/login">Log in</a> · <a href="/signup">Sign up</a>`;

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>${title} · PCGH</title>
<style>
  :root { --navy:#1F3864; --accent:#2E75B6; --light:#EAF1F8; --gray:#595959; }
  * { box-sizing: border-box; }
  body { font-family: -apple-system, Segoe UI, Helvetica, Arial, sans-serif; max-width: 880px; margin: 0 auto; padding: 24px; color: #262626; background: #fff; }
  h1 { color: var(--navy); margin-bottom: 4px; }
  h2 { color: var(--navy); border-bottom: 2px solid var(--accent); padding-bottom: 6px; margin-top: 32px; }
  nav { background: var(--light); padding: 10px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; }
  nav a { color: var(--navy); text-decoration: none; margin-right: 4px; }
  nav a:hover { text-decoration: underline; }
  table { border-collapse: collapse; width: 100%; margin: 12px 0; font-size: 14px; }
  th, td { border: 1px solid #ddd; padding: 8px 10px; text-align: left; }
  th { background: var(--navy); color: #fff; }
  tr:nth-child(even) { background: #f4f7fb; }
  .card { background: var(--light); border: 1px solid #cfe0f0; border-radius: 8px; padding: 16px; margin: 12px 0; }
  .balance { font-size: 28px; font-weight: bold; color: var(--navy); }
  form { margin: 12px 0; }
  label { display: block; margin: 10px 0 4px; font-weight: 600; font-size: 14px; }
  input[type=text], input[type=number], input[type=email], select { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 6px; font-size: 14px; }
  input[type=checkbox] { margin-right: 6px; }
  button { background: var(--accent); color: #fff; border: none; padding: 10px 18px; border-radius: 6px; font-size: 14px; cursor: pointer; margin-top: 12px; }
  button:hover { background: var(--navy); }
  .muted { color: var(--gray); font-size: 13px; }
  .pill { display: inline-block; padding: 2px 8px; border-radius: 10px; background: var(--light); color: var(--navy); font-size: 12px; margin-right: 4px; }
  .type-checks { display: flex; flex-wrap: wrap; gap: 8px; }
  .type-checks label { display: flex; align-items: center; font-weight: normal; background: #f4f7fb; padding: 4px 10px; border-radius: 6px; }
  .bar-track { background: #e2e8f0; border-radius: 4px; height: 8px; width: 100%; overflow: hidden; }
  .bar-fill { background: var(--accent); height: 100%; }
</style>
</head>
<body>
<nav>${nav}</nav>
${body}
<p class="muted" style="margin-top:40px;border-top:1px solid #eee;padding-top:12px;">
Reference MVP for PCGH — a creator discovery and community amplification platform. Implements the credit ledger, submission flow, group auto-assignment, and distribution engine from the Technical Build Plan. Not production auth/payments.
</p>
</body>
</html>`;
}

function html(res: ServerResponse, body: string, status = 200) {
  res.writeHead(status, { "Content-Type": "text/html; charset=utf-8" });
  res.end(body);
}

function redirect(res: ServerResponse, location: string) {
  res.writeHead(302, { Location: location });
  res.end();
}

async function readBody(req: IncomingMessage): Promise<URLSearchParams> {
  const chunks: Buffer[] = [];
  for await (const chunk of req) chunks.push(chunk as Buffer);
  const raw = Buffer.concat(chunks).toString("utf-8");
  return new URLSearchParams(raw);
}

function fmtDate(ms: number): string {
  return new Date(ms).toLocaleString();
}

function groupFillBar(count: number, capacity: number): string {
  const pct = capacity > 0 ? Math.min(100, Math.round((count / capacity) * 100)) : 0;
  return `<div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div>
          <div class="muted">${count} / ${capacity} members (${pct}% full)</div>`;
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url ?? "/", `http://localhost:${PORT}`);
    const asUserId = url.searchParams.get("as") ?? undefined;

    // ---------- GET /login ----------
    if (url.pathname === "/login" && req.method === "GET") {
      const users = listUsers();
      const rows = users
        .map(
          (u: any) =>
            `<tr><td>${u.name}</td><td class="muted">${u.email}</td><td>${u.tier}</td>
             <td><a href="/?as=${u.id}"><button>Log in as ${u.name}</button></a></td></tr>`
        )
        .join("");
      return html(
        res,
        layout(
          "Log in",
          `<h1>PCGH — demo login</h1>
           <p class="muted">No password. Run <code>npm run seed</code> first if this list is empty. Pick any member to see the app from their perspective, or <a href="/signup">sign up as a new member</a> to see the real group auto-assignment flow.</p>
           <table><tr><th>Name</th><th>Email</th><th>Tier</th><th></th></tr>${rows}</table>`
        )
      );
    }

    // ---------- GET/POST /signup ----------
    if (url.pathname === "/signup" && req.method === "GET") {
      const groups = listGroupsWithCounts();
      const groupRows = groups
        .map((g: any) => `<tr><td>${g.name}</td><td>${g.category}</td><td>${g.member_count} / ${g.capacity}</td></tr>`)
        .join("");
      return html(
        res,
        layout(
          "Sign up",
          `<h1>Join PCGH</h1>
           <p class="muted">New members are automatically placed into whichever community group still has room. You'll only see that one group on your dashboard — not the whole platform.</p>
           <form method="POST" action="/signup">
             <label>Name</label>
             <input type="text" name="name" required>
             <label>Email</label>
             <input type="email" name="email" required>
             <button type="submit">Sign up</button>
           </form>
           <h2>Current groups</h2>
           <table><tr><th>Group</th><th>Category</th><th>Fill</th></tr>${groupRows}</table>
           <p class="muted">If every group above is full, signup still creates your account but you'll wait for an admin to open a new group (Admin page — no code changes needed).</p>`
        )
      );
    }
    if (url.pathname === "/signup" && req.method === "POST") {
      const params = await readBody(req);
      const name = params.get("name") ?? "New member";
      const email = params.get("email") ?? "";
      try {
        const { userId, group } = signUpMember(name, email);
        if (!group) {
          return html(
            res,
            layout(
              "Welcome",
              `<h1>Welcome, ${name}!</h1>
               <p>Your account was created, but every community group is currently full. An admin needs to open a new group before you're placed — check back soon.</p>
               <p><a href="/?as=${userId}">Go to your dashboard</a></p>`,
              userId
            )
          );
        }
        return redirect(res, `/?as=${userId}`);
      } catch (err: any) {
        return html(res, layout("Error", `<h1>Couldn't sign up</h1><p>${err.message}</p><a href="/signup">Back</a>`), 400);
      }
    }

    // ---------- GET / (dashboard) ----------
    if (url.pathname === "/" && req.method === "GET") {
      if (!asUserId) return redirect(res, "/login");
      const user = getUser(asUserId);
      if (!user) return redirect(res, "/login");
      const balance = getBalance(asUserId);
      const submissions = listSubmissionsForUser(asUserId);
      const queueDue = getQueueForMember(asUserId);
      const queueUpcoming = getUpcomingForMember(asUserId);
      const myGroup = getMemberGroup(asUserId);

      const subRows = submissions
        .map(
          (s: any) =>
            `<tr><td><a href="/submission/${s.id}?as=${asUserId}">${s.url}</a></td>
             <td>${s.platform}</td><td>${s.status}</td><td>${fmtDate(s.created_at)}</td></tr>`
        )
        .join("");

      const groupCard = myGroup
        ? `<div class="card">
             <div class="muted">Your community group</div>
             <div style="font-size:20px;font-weight:bold;color:var(--navy);margin:4px 0;">${myGroup.name}</div>
             <div class="muted" style="margin-bottom:8px;">${myGroup.category}</div>
           </div>`
        : `<div class="card"><p class="muted">You're not in a group yet — every group was full when you signed up. An admin needs to open a new one.</p></div>`;

      return html(
        res,
        layout(
          "Dashboard",
          `<h1>Welcome, ${user.name}</h1>
           <div class="card">
             <div class="muted">Credit balance</div>
             <div class="balance">${balance.toLocaleString()} credits</div>
           </div>
           ${groupCard}
           <p><span class="pill">${queueDue.length} tasks due now</span>
              <span class="pill">${queueUpcoming.length} scheduled</span>
              <span class="pill">${submissions.length} submissions</span></p>
           <h2>Your submissions</h2>
           ${submissions.length ? `<table><tr><th>URL</th><th>Platform</th><th>Status</th><th>Submitted</th></tr>${subRows}</table>` : `<p class="muted">No submissions yet. <a href="/submit?as=${asUserId}">Submit your first link</a>.</p>`}
          `,
          asUserId
        )
      );
    }

    // ---------- GET/POST /submit ----------
    if (url.pathname === "/submit" && req.method === "GET") {
      if (!asUserId) return redirect(res, "/login");
      const balance = getBalance(asUserId);
      const typeChecks = ALL_ENGAGEMENT_TYPES.map(
        (t) => `<label><input type="checkbox" name="types" value="${t}" checked> ${t.replace("_", " ")}</label>`
      ).join("");
      return html(
        res,
        layout(
          "Submit content",
          `<h1>Submit content</h1>
           <p class="muted">Costs 100 credits per link. Your balance: <strong>${balance}</strong>.</p>
           <form method="POST" action="/submit?as=${asUserId}">
             <label>Content URL</label>
             <input type="text" name="url" placeholder="https://..." required>
             <label>Platform</label>
             <select name="platform">
               <option>Instagram</option><option>TikTok</option><option>YouTube</option>
               <option>X / Twitter</option><option>Blog / Website</option><option>Other</option>
             </select>
             <label>Requested engagement types</label>
             <div class="type-checks">${typeChecks}</div>
             <button type="submit">Submit (100 credits)</button>
           </form>`,
          asUserId
        )
      );
    }
    if (url.pathname === "/submit" && req.method === "POST") {
      const params = await readBody(req);
      const owner = asUserId ?? params.get("as");
      if (!owner) return redirect(res, "/login");
      const link = params.get("url") ?? "";
      const platform = params.get("platform") ?? "Other";
      const types = params.getAll("types") as EngagementType[];
      try {
        submitContent(owner, link, platform, types);
        return redirect(res, `/?as=${owner}`);
      } catch (err: any) {
        return html(res, layout("Error", `<h1>Couldn't submit</h1><p>${err.message}</p><a href="/submit?as=${owner}">Back</a>`, owner), 400);
      }
    }

    // ---------- GET /credits/buy + POST ----------
    if (url.pathname === "/credits/buy" && req.method === "GET") {
      if (!asUserId) return redirect(res, "/login");
      return html(
        res,
        layout(
          "Buy credits",
          `<h1>Buy credits</h1>
           <p class="muted">Mock purchase — wire up Stripe here in production (Section 5 of the Technical Build Plan).</p>
           <form method="POST" action="/credits/buy?as=${asUserId}">
             <label>Amount</label>
             <select name="amount">
               <option value="500">500 credits — $7.50</option>
               <option value="1000" selected>1,000 credits — $15</option>
               <option value="2500">2,500 credits — $32.50</option>
             </select>
             <button type="submit">Buy</button>
           </form>`,
          asUserId
        )
      );
    }
    if (url.pathname === "/credits/buy" && req.method === "POST") {
      const params = await readBody(req);
      const owner = asUserId ?? params.get("as");
      if (!owner) return redirect(res, "/login");
      const amount = Number(params.get("amount") ?? 0);
      purchaseCredits(owner, amount);
      return redirect(res, `/?as=${owner}`);
    }

    // ---------- GET /queue + POST /queue/complete ----------
    if (url.pathname === "/queue" && req.method === "GET") {
      if (!asUserId) return redirect(res, "/login");
      const due = getQueueForMember(asUserId);
      const upcoming = getUpcomingForMember(asUserId);
      const dueRows = due
        .map(
          (a: any) =>
            `<tr><td>${a.url}</td><td>${a.platform}</td><td>${a.engagement_type}</td>
             <td>${fmtDate(a.scheduled_at)}</td>
             <td><form method="POST" action="/queue/complete?as=${asUserId}" style="margin:0">
                   <input type="hidden" name="assignmentId" value="${a.id}">
                   <button type="submit">Mark complete</button>
                 </form></td></tr>`
        )
        .join("");
      const upcomingRows = upcoming
        .map((a: any) => `<tr><td>${a.url}</td><td>${a.engagement_type}</td><td>${fmtDate(a.scheduled_at)}</td></tr>`)
        .join("");

      return html(
        res,
        layout(
          "My queue",
          `<h1>My engagement queue</h1>
           <h2>Due now (${due.length})</h2>
           ${due.length ? `<table><tr><th>Content</th><th>Platform</th><th>Action</th><th>Scheduled</th><th></th></tr>${dueRows}</table>` : `<p class="muted">Nothing due right now.</p>`}
           <h2>Scheduled — not yet due (${upcoming.length})</h2>
           ${upcoming.length ? `<table><tr><th>Content</th><th>Action</th><th>Scheduled for</th></tr>${upcomingRows}</table>` : `<p class="muted">Nothing scheduled.</p>`}
           <p class="muted">These are staggered on purpose — see "Time Delays" in the business model. In production, "mark complete" would be replaced by real verification (Section 4 of the build plan), not a self-reported click.</p>`,
          asUserId
        )
      );
    }
    if (url.pathname === "/queue/complete" && req.method === "POST") {
      const params = await readBody(req);
      const owner = asUserId ?? params.get("as");
      const assignmentId = params.get("assignmentId");
      if (!owner || !assignmentId) return redirect(res, "/login");
      const a = getAssignment(assignmentId);
      if (a && a.member_user_id === owner) completeAssignment(assignmentId);
      return redirect(res, `/queue?as=${owner}`);
    }

    // ---------- GET /submission/:id ----------
    if (url.pathname.startsWith("/submission/") && req.method === "GET") {
      const id = url.pathname.split("/")[2];
      const sub = getSubmission(id);
      if (!sub) return html(res, layout("Not found", "<h1>Submission not found</h1>"), 404);
      const stats = getSubmissionStats(id);
      const breakdownRows = stats.breakdown
        .map((b: any) => `<tr><td>${b.engagement_type}</td><td>${b.status}</td><td>${b.n}</td></tr>`)
        .join("");
      return html(
        res,
        layout(
          "Submission",
          `<h1>Submission stats</h1>
           <p><a href="${sub.url}" target="_blank">${sub.url}</a> · ${sub.platform} · status: <strong>${sub.status}</strong></p>
           <div class="card">
             <p><span class="pill">${stats.totalAssigned} assigned</span>
                <span class="pill">${stats.totalCompleted} completed</span>
                <span class="pill">${stats.distinctGroups} distinct groups reached</span></p>
           </div>
           <h2>Breakdown by engagement type</h2>
           ${stats.breakdown.length ? `<table><tr><th>Type</th><th>Status</th><th>Count</th></tr>${breakdownRows}</table>` : `<p class="muted">Not distributed yet — run the distribution worker from the Admin page.</p>`}
          `,
          asUserId
        )
      );
    }

    // ---------- GET /admin + POST /admin/run-distribution + POST /admin/groups/create ----------
    if (url.pathname === "/admin" && req.method === "GET") {
      const groups = listGroupsWithCounts();
      const groupRows = groups
        .map(
          (g: any) => `<tr><td>${g.name}</td><td>${g.category}</td><td style="min-width:160px">${groupFillBar(g.member_count, g.capacity)}</td></tr>`
        )
        .join("");
      return html(
        res,
        layout(
          "Admin",
          `<h1>Admin</h1>

           <h2>Distribution worker</h2>
           <p class="muted">In production this runs on a schedule (cron/job queue). Here you trigger it manually to see the algorithm run against pending submissions.</p>
           <form method="POST" action="/admin/run-distribution?as=${asUserId ?? ""}">
             <button type="submit">Run distribution now</button>
           </form>

           <h2>Community groups (${groups.length})</h2>
           <table><tr><th>Group</th><th>Category</th><th>Fill</th></tr>${groupRows}</table>

           <h2>Create a new group</h2>
           <p class="muted">This is the entire mechanism for adding community capacity — no code changes. Once a group fills up, new signups automatically move to the next one you create here.</p>
           <form method="POST" action="/admin/groups/create?as=${asUserId ?? ""}">
             <label>Group name</label>
             <input type="text" name="name" placeholder="e.g. Travel & Lifestyle" required>
             <label>Category</label>
             <input type="text" name="category" placeholder="e.g. travel" required>
             <label>Capacity</label>
             <input type="text" name="capacity" value="100" required>
             <button type="submit">Create group</button>
           </form>`,
          asUserId
        )
      );
    }
    if (url.pathname === "/admin/run-distribution" && req.method === "POST") {
      const results = runDistributionWorker();
      const rows = results.map((r) => `<tr><td>${r.submissionId}</td><td>${r.assigned}</td></tr>`).join("");
      return html(
        res,
        layout(
          "Distribution run",
          `<h1>Distribution worker ran</h1>
           ${results.length ? `<table><tr><th>Submission</th><th>Assignments created</th></tr>${rows}</table>` : `<p class="muted">No pending submissions.</p>`}
           <p><a href="/admin?as=${asUserId ?? ""}">Back to admin</a></p>`,
          asUserId
        )
      );
    }
    if (url.pathname === "/admin/groups/create" && req.method === "POST") {
      const params = await readBody(req);
      const name = params.get("name") ?? "New group";
      const category = params.get("category") ?? "general";
      const capacity = Number(params.get("capacity") ?? 100) || 100;
      createGroup(name, category, capacity);
      return redirect(res, `/admin?as=${asUserId ?? ""}`);
    }

    return html(res, layout("Not found", "<h1>404</h1>"), 404);
  } catch (err: any) {
    console.error(err);
    res.writeHead(500, { "Content-Type": "text/plain" });
    res.end("Internal error: " + err.message);
  }
});

server.listen(PORT, () => {
  console.log(`PCGH reference MVP running at http://localhost:${PORT}`);
  console.log(`If this is a fresh database, run: npm run seed`);
});
