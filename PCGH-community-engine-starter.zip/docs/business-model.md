# Business Model

Describe credit purchases, community distribution, and creator growth.
