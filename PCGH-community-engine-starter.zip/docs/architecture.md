# Architecture

Distribution engine, rotation engine, credit engine, and group engine.
